// ========================================
// PropFirm Compare - Main Application
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    initNavigation();
    initComparison();
    initCalculator();
    initFAQ();
    initModals();
    initScrollAnimations();
});

// ========================================
// Theme Toggle
// ========================================

function initTheme() {
    const themeToggle = document.getElementById('themeToggle');
    const html = document.documentElement;
    const icon = themeToggle.querySelector('i');

    // Check saved theme or default to dark
    const savedTheme = localStorage.getItem('theme') || 'dark';
    html.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);

    themeToggle.addEventListener('click', () => {
        const currentTheme = html.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeIcon(newTheme);
    });
}

function updateThemeIcon(theme) {
    const icon = document.querySelector('#themeToggle i');
    if (theme === 'dark') {
        icon.className = 'fas fa-moon';
    } else {
        icon.className = 'fas fa-sun';
    }
}

// ========================================
// Navigation
// ========================================

function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-links a');
    const sections = document.querySelectorAll('section[id]');

    // Smooth scroll and active state
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Update active nav on scroll
    window.addEventListener('scroll', () => {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            if (scrollY >= sectionTop) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === '#' + current) {
                link.classList.add('active');
            }
        });
    });

    // Mobile menu
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navLinksContainer = document.querySelector('.nav-links');

    mobileMenuBtn.addEventListener('click', () => {
        navLinksContainer.classList.toggle('mobile-open');
    });
}

// ========================================
// Comparison Feature
// ========================================

function initComparison() {
    const leftSelect = document.getElementById('compareLeft');
    const rightSelect = document.getElementById('compareRight');
    const tableContainer = document.getElementById('comparisonTable');

    // Initial render
    renderComparison();

    // Event listeners
    leftSelect.addEventListener('change', renderComparison);
    rightSelect.addEventListener('change', renderComparison);

    function renderComparison() {
        const leftKey = leftSelect.value;
        const rightKey = rightSelect.value;
        const leftFirm = firmsData[leftKey];
        const rightFirm = firmsData[rightKey];

        const table = document.createElement('table');
        table.className = 'comparison-table';

        // Header
        const thead = document.createElement('thead');
        thead.innerHTML = `
            <tr>
                <th>المعيار</th>
                <th>${leftFirm.name}</th>
                <th>${rightFirm.name}</th>
            </tr>
        `;
        table.appendChild(thead);

        const tbody = document.createElement('tbody');

        // Helper to get value
        const getValue = (firm, key) => {
            switch(key) {
                case 'rating': return firm.rating + '/10';
                case 'category': return firm.category;
                case 'platforms': return firm.platforms.join('، ');
                case 'timeLimit': return firm.timeLimit;
                case 'consistencyRule': return firm.consistencyRule;
                case 'models': return firm.models.length + ' نماذج';
                case 'lowestPrice': 
                    const allPrices = firm.models.flatMap(m => m.prices.map(p => parseFloat(p.price.replace(/[^0-9.]/g, ''))));
                    const minPrice = Math.min(...allPrices.filter(p => !isNaN(p)));
                    return isFinite(minPrice) ? '$' + minPrice.toFixed(2) : 'غير متوفر';
                case 'highestLeverage':
                    const leverages = firm.models.map(m => {
                        const match = m.leverage.match(/1:(\d+)/);
                        return match ? parseInt(match[1]) : 0;
                    });
                    const maxLev = Math.max(...leverages);
                    return maxLev > 0 ? '1:' + maxLev : 'غير محدد';
                case 'highestProfitSplit':
                    const splits = firm.models.map(m => {
                        const match = m.profitSplit.match(/(\d+)/);
                        return match ? parseInt(match[1]) : 0;
                    });
                    const maxSplit = Math.max(...splits);
                    return maxSplit > 0 ? maxSplit + '%' : firm.models[0].profitSplit;
                case 'fastestPayout':
                    const payouts = firm.models.map(m => m.firstPayout);
                    return payouts.join(' / ');
                case 'eaTrading':
                    return firm.rules.eaTrading || 'غير موثق';
                case 'newsTrading':
                    return firm.rules.newsTradingEvaluation;
                default: return '';
            }
        };

        // Compare and highlight
        comparisonCriteria.forEach(criteria => {
            const row = document.createElement('tr');
            const leftVal = getValue(leftFirm, criteria.key);
            const rightVal = getValue(rightFirm, criteria.key);

            let leftClass = '';
            let rightClass = '';

            // Simple comparison logic for numeric values
            if (criteria.type === 'rating') {
                const leftNum = parseFloat(leftVal);
                const rightNum = parseFloat(rightVal);
                if (leftNum > rightNum) { leftClass = 'winner'; rightClass = 'loser'; }
                else if (rightNum > leftNum) { leftClass = 'loser'; rightClass = 'winner'; }
                else { leftClass = rightClass = 'equal'; }
            }

            row.innerHTML = `
                <td>${criteria.label}</td>
                <td class="${leftClass}">${leftVal}</td>
                <td class="${rightClass}">${rightVal}</td>
            `;
            tbody.appendChild(row);
        });

        table.appendChild(tbody);
        tableContainer.innerHTML = '';
        tableContainer.appendChild(table);
    }
}

// ========================================
// Calculator
// ========================================

function initCalculator() {
    const accountSize = document.getElementById('calcAccountSize');
    const profitPercent = document.getElementById('calcProfitPercent');
    const splitPercent = document.getElementById('calcSplitPercent');
    const challengeFee = document.getElementById('calcChallengeFee');

    const profitValue = document.getElementById('profitValue');
    const splitValue = document.getElementById('splitValue');
    const monthlyProfit = document.getElementById('monthlyProfit');
    const yourShare = document.getElementById('yourShare');
    const roiPercent = document.getElementById('roiPercent');
    const yearlyProfit = document.getElementById('yearlyProfit');

    function calculate() {
        const size = parseFloat(accountSize.value);
        const profit = parseFloat(profitPercent.value);
        const split = parseFloat(splitPercent.value);
        const fee = parseFloat(challengeFee.value) || 0;

        profitValue.textContent = profit + '%';
        splitValue.textContent = split + '%';

        const monthly = size * (profit / 100);
        const share = monthly * (split / 100);
        const yearly = share * 12;
        const roi = fee > 0 ? ((yearly / fee) * 100).toFixed(0) : 0;

        monthlyProfit.textContent = '$' + monthly.toLocaleString('en-US', {maximumFractionDigits: 0});
        yourShare.textContent = '$' + share.toLocaleString('en-US', {maximumFractionDigits: 0});
        roiPercent.textContent = roi + '%';
        yearlyProfit.textContent = '$' + yearly.toLocaleString('en-US', {maximumFractionDigits: 0});
    }

    accountSize.addEventListener('change', calculate);
    profitPercent.addEventListener('input', calculate);
    splitPercent.addEventListener('input', calculate);
    challengeFee.addEventListener('input', calculate);

    // Initial calculation
    calculate();
}

// ========================================
// FAQ Accordion
// ========================================

function initFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');

            // Close all
            faqItems.forEach(i => i.classList.remove('active'));

            // Open clicked if wasn't active
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
}

// ========================================
// Review Modals
// ========================================

function initModals() {
    const modal = document.getElementById('reviewModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    const modalClose = document.querySelector('.modal-close');
    const modalOverlay = document.querySelector('.modal-overlay');

    // Open modal buttons
    document.querySelectorAll('.view-review-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const firmKey = btn.getAttribute('data-firm');
            const firm = firmsData[firmKey];
            openReviewModal(firm);
        });
    });

    // Footer links
    document.querySelectorAll('.footer-links a[data-firm]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const firmKey = link.getAttribute('data-firm');
            const firm = firmsData[firmKey];
            openReviewModal(firm);
        });
    });

    function openReviewModal(firm) {
        modalTitle.textContent = 'مراجعة ' + firm.name;
        modalBody.innerHTML = generateReviewHTML(firm);
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeModal() {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    modalClose.addEventListener('click', closeModal);
    modalOverlay.addEventListener('click', closeModal);
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeModal();
    });
}

function generateReviewHTML(firm) {
    let modelsHTML = '';
    firm.models.forEach(model => {
        let pricesHTML = '';
        model.prices.forEach(p => {
            pricesHTML += `<tr><td>${p.size}</td><td>${p.price}</td></tr>`;
        });

        modelsHTML += `
            <h3>${model.name}</h3>
            <table class="review-table">
                <tr><th>العنصر</th><th>القيمة</th></tr>
                <tr><td>نوع النموذج</td><td>${model.type}</td></tr>
                <tr><td>هدف الربح</td><td>${model.profitTarget}</td></tr>
                <tr><td>الخسارة اليومية القصوى</td><td>${model.maxDailyLoss}</td></tr>
                <tr><td>الخسارة القصوى</td><td>${model.maxLoss}</td></tr>
                <tr><td>نوع الدروداون</td><td>${model.drawdownType}</td></tr>
                <tr><td>الحد الأدنى لأيام التداول</td><td>${model.minDays}</td></tr>
                <tr><td>الرافعة</td><td>${model.leverage}</td></tr>
                <tr><td>أول سحب</td><td>${model.firstPayout}</td></tr>
                <tr><td>Profit Split</td><td>${model.profitSplit}</td></tr>
                <tr><td>العمولة</td><td>${model.commission}</td></tr>
            </table>
            <h4>الأسعار</h4>
            <table class="review-table">
                <tr><th>حجم الحساب</th><th>السعر</th></tr>
                ${pricesHTML}
            </table>
        `;
    });

    let prosHTML = firm.pros.map(p => `<li>${p}</li>`).join('');
    let consHTML = firm.cons.map(c => `<li>${c}</li>`).join('');
    let faqHTML = firm.faq.map(f => `<p><strong>${f.q}</strong><br>${f.a}</p>`).join('');

    return `
        <div class="review-content">
            <div class="review-rating-box">
                <span class="score">${firm.rating}</span>
                <span class="label">/ 10<br>التقييم العام</span>
            </div>

            <h3>نظرة عامة</h3>
            <p><strong>الشركة:</strong> ${firm.fullName}</p>
            <p><strong>السوق:</strong> ${firm.category}</p>
            <p><strong>المنصات:</strong> ${firm.platforms.join('، ')}</p>
            <p><strong>نوع الحساب بعد النجاح:</strong> ${firm.accountType}</p>
            <p><strong>Time Limit:</strong> ${firm.timeLimit}</p>
            <p><strong>Consistency Rule:</strong> ${firm.consistencyRule}</p>

            <h3>أنواع الحسابات</h3>
            ${modelsHTML}

            <h3>القواعد التشغيلية</h3>
            <table class="review-table">
                <tr><th>البند</th><th>القيمة</th></tr>
                <tr><td>تداول الأخبار (التقييم)</td><td>${firm.rules.newsTradingEvaluation}</td></tr>
                <tr><td>تداول الأخبار (التمويل)</td><td>${firm.rules.newsTradingFunded}</td></tr>
                <tr><td>Overnight Holding</td><td>${firm.rules.overnightHolding}</td></tr>
                <tr><td>Weekend Holding</td><td>${firm.rules.weekendHolding}</td></tr>
                <tr><td>Best Day Rule</td><td>${firm.rules.bestDayRule}</td></tr>
                <tr><td>Time Limit</td><td>${firm.rules.timeLimit}</td></tr>
                <tr><td>EA Trading</td><td>${firm.rules.eaTrading}</td></tr>
            </table>

            <h3>السحب والأرباح</h3>
            <table class="review-table">
                <tr><th>البند</th><th>القيمة</th></tr>
                <tr><td>أول سحب</td><td>${firm.payout.firstPayout}</td></tr>
                <tr><td>دورية السحب</td><td>${firm.payout.frequency}</td></tr>
                <tr><td>استرداد الرسوم</td><td>${firm.payout.refund}</td></tr>
                <tr><td>الحد الأدنى للسحب</td><td>${firm.payout.minWithdrawal}</td></tr>
            </table>

            <h3>الإيجابيات والسلبيات</h3>
            <div class="pros-cons">
                <div class="pros">
                    <h4><i class="fas fa-check-circle"></i> الإيجابيات</h4>
                    <ul>${prosHTML}</ul>
                </div>
                <div class="cons">
                    <h4><i class="fas fa-times-circle"></i> السلبيات</h4>
                    <ul>${consHTML}</ul>
                </div>
            </div>

            <h3>الحكم النهائي</h3>
            <p>${firm.verdict}</p>

            <h3>الأسئلة الشائعة</h3>
            ${faqHTML}
        </div>
    `;
}

// ========================================
// Scroll Animations
// ========================================

function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.section-header, .firm-card, .faq-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}
