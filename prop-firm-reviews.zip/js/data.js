// ========================================
// PropFirm Compare - Data Module
// All firm data extracted from reviews
// ========================================

const firmsData = {
    ftmo: {
        name: "FTMO",
        fullName: "FTMO CFD",
        rating: 8.9,
        category: "عقود مقابل الفروقات (CFD)",
        platforms: ["MT4", "MT5", "cTrader"],
        accountType: "FTMO Account ضمن بيئة محاكاة",
        timeLimit: "غير محدود في 1-Step و2-Step",
        consistencyRule: "غير موجود كقاعدة مستقلة",

        models: [
            {
                name: "FTMO Challenge: 1-Step",
                type: "Challenge",
                profitTarget: "10%",
                maxDailyLoss: "3%",
                maxLoss: "10%",
                drawdownType: "EOD Trailing Max Loss",
                minDays: "لا يوجد حد أدنى صريح",
                leverage: "غير محدد",
                firstPayout: "بعد 14 يومًا",
                profitSplit: "90%",
                commission: "غير مذكور",
                prices: [
                    { size: "$10,000", price: "€79" },
                    { size: "$25,000", price: "€199" },
                    { size: "$50,000", price: "€319" },
                    { size: "$100,000", price: "€499" },
                    { size: "$200,000", price: "€999" }
                ]
            },
            {
                name: "FTMO Challenge: 2-Step",
                type: "Challenge",
                profitTarget: "10% ثم 5%",
                maxDailyLoss: "5%",
                maxLoss: "10%",
                drawdownType: "Static Max Loss",
                minDays: "4 أيام في كل مرحلة",
                leverage: "غير محدد",
                firstPayout: "بعد 14 يومًا",
                profitSplit: "80% → 90% مع Scaling",
                commission: "غير مذكور",
                prices: [
                    { size: "$10,000", price: "€89" },
                    { size: "$25,000", price: "€250" },
                    { size: "$50,000", price: "€345" },
                    { size: "$100,000", price: "€439" },
                    { size: "$200,000", price: "€1,080" }
                ]
            }
        ],

        swingAccount: {
            available: true,
            via: "2-Step فقط",
            features: ["Overnight Holding مسموح", "Weekend Holding مسموح", "Trading during selected macroeconomic news مسموح"]
        },

        rules: {
            newsTradingEvaluation: "مسموح بحرية",
            newsTradingFunded: "قيود على الأخبار الاقتصادية المحددة (Standard)، Swing مستثنى",
            overnightHolding: "مسموح خلال التقييم، مقيد بعد النجاح (Standard)، مسموح (Swing)",
            weekendHolding: "مسموح خلال التقييم، مقيد بعد النجاح (Standard)، مسموح (Swing)",
            bestDayRule: "موجود في 1-Step (50%)",
            timeLimit: "غير محدود",
            eaTrading: "غير موثق تفصيلياً"
        },

        payout: {
            firstPayout: "بعد 14 يومًا من أول يوم تداول",
            frequency: "عند الطلب (1-Step)، كل أسبوعين (2-Step)",
            refund: "نعم، مع أول Reward withdrawal ناجح",
            minWithdrawal: "غير مذكور"
        },

        pros: [
            "وضوح قوي في Trading Objectives",
            "1-Step و2-Step مفصولان بوضوح",
            "دعم MT4 وMT5 وcTrader",
            "حساب Swing ميزة مهمة",
            "خطة نمو رسمية واضحة حتى 2,000,000 دولار",
            "1-Step يعطي 90% من الأرباح مباشرة"
        ],

        cons: [
            "1-Step أكثر صرامة (Max Daily Loss 3% + Best Day Rule)",
            "Swing متاح فقط عبر 2-Step",
            "جدول الرسوم الكامل حسب كل أصل غير واضح",
            "لا يوجد Time Limit لكن القيود تشغيلية"
        ],

        verdict: "إذا كنت تبحث عن شركة CFD ذات بنية واضحة وقواعد مفهومة وسمعة قوية، فـ FTMO من أقوى الخيارات. 2-Step هو الخيار الأكثر توازنًا، و1-Step لمن يريد سرعة أعلى.",

        faq: [
            { q: "هل FTMO تقدم حسابًا حقيقيًا أم محاكاة؟", a: "محاكاة. FTMO تصرح بأنها تقدم simulated trading services وأدوات تعليمية، وليست وسيطًا." },
            { q: "هل تداول الأخبار مسموح؟", a: "نعم خلال التقييم في 1-Step و2-Step. وبعد النجاح على الحساب العادي توجد قيود، بينما Swing يسمح بها." },
            { q: "هل يمكن الاحتفاظ بالصفقات لليوم التالي؟", a: "نعم خلال Challenge وVerification. وبعد النجاح، الحساب العادي مقيّد بينما Swing يسمح بالاحتفاظ." }
        ]
    },

    fundednext: {
        name: "FundedNext",
        fullName: "FundedNext CFD",
        rating: 8.5,
        category: "عقود مقابل الفروقات (CFD)",
        platforms: ["MT4", "MT5", "cTrader", "Match-Trader", "TradingView (للتحليل)"],
        accountType: "FundedNext Account ضمن بيئة محاكاة",
        timeLimit: "غير محدود في النماذج المعروضة",
        consistencyRule: "غير موجود في النماذج المعروضة",

        models: [
            {
                name: "Stellar 1-Step",
                type: "Challenge",
                profitTarget: "10%",
                maxDailyLoss: "3%",
                maxLoss: "6%",
                drawdownType: "Balance Based",
                minDays: "2 أيام",
                leverage: "1:30",
                firstPayout: "5 أيام عمل",
                profitSplit: "حتى 95%",
                commission: "$5/Lot",
                prices: [
                    { size: "$6,000", price: "$65.99" },
                    { size: "$15,000", price: "$129.99" },
                    { size: "$25,000", price: "$219.99" },
                    { size: "$50,000", price: "$329.99" },
                    { size: "$100,000", price: "$569.99" },
                    { size: "$200,000", price: "$1,099.99" }
                ]
            },
            {
                name: "Stellar 2-Step",
                type: "Challenge",
                profitTarget: "8% ثم 5%",
                maxDailyLoss: "5%",
                maxLoss: "10%",
                drawdownType: "Balance Based",
                minDays: "5 أيام",
                leverage: "1:100",
                firstPayout: "21 يومًا",
                profitSplit: "حتى 95%",
                commission: "$5/Lot",
                prices: [
                    { size: "$6,000", price: "$59.99" },
                    { size: "$15,000", price: "$119.99" },
                    { size: "$25,000", price: "$199.99" },
                    { size: "$50,000", price: "$299.99" },
                    { size: "$100,000", price: "$549.99" },
                    { size: "$200,000", price: "$1,099.99" }
                ]
            },
            {
                name: "Stellar Lite",
                type: "Challenge",
                profitTarget: "8% ثم 4%",
                maxDailyLoss: "4%",
                maxLoss: "8%",
                drawdownType: "Balance Based",
                minDays: "5 أيام",
                leverage: "1:100",
                firstPayout: "21 يومًا",
                profitSplit: "حتى 95%",
                commission: "$7/Lot",
                prices: [
                    { size: "$5,000", price: "$32.99" },
                    { size: "$10,000", price: "$59.99" },
                    { size: "$25,000", price: "$139.99" },
                    { size: "$50,000", price: "$229.99" },
                    { size: "$100,000", price: "$399.99" },
                    { size: "$200,000", price: "$798.99" }
                ]
            },
            {
                name: "Stellar Instant",
                type: "Instant",
                profitTarget: "لا يوجد",
                maxDailyLoss: "لا يوجد",
                maxLoss: "6% Trailing",
                drawdownType: "Trailing",
                minDays: "0",
                leverage: "1:100",
                firstPayout: "On-Demand عند 5% أو 14 يومًا",
                profitSplit: "70% → 80%",
                commission: "غير مذكور رسميًا",
                prices: [
                    { size: "$2,000", price: "$59.99" },
                    { size: "$5,000", price: "$149.99" },
                    { size: "$10,000", price: "$299.99" },
                    { size: "$20,000", price: "$599.99" }
                ]
            }
        ],

        rules: {
            newsTradingEvaluation: "مسموح",
            newsTradingFunded: "مسموح مع قواعد إضافية",
            overnightHolding: "غير مذكور رسميًا",
            weekendHolding: "غير مذكور رسميًا",
            bestDayRule: "غير موجود",
            timeLimit: "غير محدود",
            eaTrading: "مسموح في Instant بشروط"
        },

        payout: {
            firstPayout: "5 أيام عمل (1-Step)، 21 يومًا (2-Step/Lite)، On-Demand (Instant)",
            frequency: "5 أيام عمل (1-Step)، كل أسبوعين (2-Step/Lite)",
            refund: "غير مذكور بوضوح",
            minWithdrawal: "غير مذكور"
        },

        pros: [
            "تنوع واضح بين 4 نماذج",
            "لا يوجد Time Limit",
            "لا توجد Consistency Rule",
            "منصات متعددة: MT4/MT5/cTrader/Match-Trader",
            "2-Step وLite يقدمان Balance Based أسهل نفسيًا",
            "أول سحب سريع في 1-Step (5 أيام)"
        ],

        cons: [
            "بعض نقاط القرار غير منشورة (Spread/Slippage/Fees)",
            "1-Step أضيق في الخسارة اليومية والكلية",
            "Lite أرخص لكنه أعلى عمولة ($7/Lot)",
            "Instant ليس الأسهل بسبب Trailing Drawdown",
            "جميع الحسابات Simulated"
        ],

        verdict: "إذا كان هدفك حساب CFD واضح القواعد وبدون time limit، فـ FundedNext من الخيارات الجيدة. للمبتدئ: Stellar 2-Step للتوازن، وStellar Lite إذا كانت ميزانية الدخول أهم.",

        faq: [
            { q: "هل الحساب النهائي Live أم Simulated؟", a: "Simulated. هذا موثق في المواد الرسمية." },
            { q: "هل تداول الأخبار مسموح؟", a: "نعم، ومذكور في المقارنة العامة." },
            { q: "ما أول موعد للسحب في 1-Step؟", a: "بعد 5 أيام عمل." }
        ]
    },

    fundingpips: {
        name: "FundingPips",
        fullName: "FundingPips CFD",
        rating: 8.2,
        category: "عقود مقابل الفروقات (CFD)",
        platforms: ["MT5", "cTrader", "Match-Trader", "TradeLocker"],
        accountType: "Master Account ضمن بيئة محاكاة",
        timeLimit: "غير محدود في جميع النماذج",
        consistencyRule: "غير موجود في التقييم القياسي",

        models: [
            {
                name: "2-Step Standard",
                type: "Challenge",
                profitTarget: "8% ثم 5%",
                maxDailyLoss: "5%",
                maxLoss: "10%",
                drawdownType: "Static",
                minDays: "3 أيام",
                leverage: "1:100",
                firstPayout: "أسبوعي (60%)",
                profitSplit: "80% → 100%",
                commission: "غير مذكور رسميًا",
                prices: [
                    { size: "$5,000", price: "$55" },
                    { size: "$10,000", price: "$88" },
                    { size: "$25,000", price: "$165" },
                    { size: "$50,000", price: "$235" },
                    { size: "$100,000", price: "$400" },
                    { size: "$200,000", price: "$800" }
                ]
            },
            {
                name: "2-Step Pro",
                type: "Challenge",
                profitTarget: "6% ثم 6%",
                maxDailyLoss: "3%",
                maxLoss: "6%",
                drawdownType: "Static",
                minDays: "1 يوم",
                leverage: "1:100",
                firstPayout: "أسبوعي (80%)",
                profitSplit: "80%",
                commission: "غير مذكور رسميًا",
                prices: [
                    { size: "$5,000", price: "$29" },
                    { size: "$10,000", price: "$58" },
                    { size: "$25,000", price: "$139" },
                    { size: "$50,000", price: "$249" },
                    { size: "$100,000", price: "$449" }
                ]
            },
            {
                name: "1-Step",
                type: "Challenge",
                profitTarget: "10%",
                maxDailyLoss: "5%",
                maxLoss: "10%",
                drawdownType: "Static",
                minDays: "3 أيام",
                leverage: "1:50",
                firstPayout: "أسبوعي (60%)",
                profitSplit: "60% → 90%",
                commission: "غير مذكور رسميًا",
                prices: [
                    { size: "$5,000", price: "$49" },
                    { size: "$10,000", price: "$88" },
                    { size: "$25,000", price: "$179" },
                    { size: "$50,000", price: "$299" },
                    { size: "$100,000", price: "$549" },
                    { size: "$200,000", price: "$999" }
                ]
            },
            {
                name: "Zero Instant",
                type: "Instant",
                profitTarget: "لا يوجد",
                maxDailyLoss: "3%",
                maxLoss: "5% Trailing",
                drawdownType: "Trailing",
                minDays: "0",
                leverage: "1:100",
                firstPayout: "كل أسبوعين (95%)",
                profitSplit: "95%",
                commission: "غير مذكور رسميًا",
                prices: [
                    { size: "$5,000", price: "$69" },
                    { size: "$10,000", price: "$139" },
                    { size: "$25,000", price: "$299" },
                    { size: "$50,000", price: "$499" },
                    { size: "$100,000", price: "$999" }
                ]
            }
        ],

        rules: {
            newsTradingEvaluation: "مسموح",
            newsTradingFunded: "مقيد (قيود على الأرباح المحتسبة للسحب)",
            overnightHolding: "مسموح",
            weekendHolding: "مسموح (ما عدا Zero)",
            bestDayRule: "غير موجود",
            timeLimit: "غير محدود",
            eaTrading: "مسموح",
            hedging: "ممنوع عبر الحسابات",
            copyTrading: "بين حساباتك فقط"
        },

        payout: {
            firstPayout: "أسبوعي (60-80%)، كل أسبوعين (Zero 95%)",
            frequency: "أسبوعي / كل أسبوعين / شهري / عند الطلب",
            refund: "نعم في بعض النماذج بعد عدد محدد من المدفوعات",
            minWithdrawal: "1% من رصيد الحساب"
        },

        pros: [
            "تنوع واضح بين 4 نماذج",
            "لا يوجد Time Limit",
            "Static Drawdown أسهل نفسيًا من Trailing",
            "مرونة في دورات السحب",
            "Profit Split قد يصل إلى 100%",
            "EAs والمنصات الحديثة مدعومة"
        ],

        cons: [
            "Spread/Slippage/Commission غير منشورة بوضوح",
            "Max Risk Per Trade في Master Account قد يكون قاسيًا",
            "2-Step Pro أضيق بكثير من Standard",
            "Zero Instant الأكثر قسوة بسبب Trailing Drawdown",
            "MT4 غير متاح",
            "جميع الحسابات Simulated"
        ],

        verdict: "للمبتدئ الجاد: 2-Step Standard هو الخيار الافتراضي. إذا كانت ميزانية الدخول هي الأولوية: 2-Step Pro. للسرعة: 1-Step. للدخول الفوري: Zero Instant (مع فهم كامل للمخاطر).",

        faq: [
            { q: "هل الحساب النهائي Live أم Simulated؟", a: "Simulated. هذا متسق مع بنية Master Account." },
            { q: "هل تداول الأخبار مسموح؟", a: "نعم في التقييم. في التمويل توجد قيود على الأرباح المحتسبة للسحب." },
            { q: "هل يمكن استرداد رسوم التقييم؟", a: "نعم في بعض النماذج بعد عدد محدد من المدفوعات الناجحة." }
        ]
    },

    the5ers: {
        name: "The5ers",
        fullName: "The5ers CFD",
        rating: 8.7,
        category: "عقود مقابل الفروقات (CFD)",
        platforms: ["MT5", "cTrader"],
        accountType: "Funded Trader / The5ers funded account ضمن بيئة محاكاة",
        timeLimit: "غير محدود في البرامج الثلاثة",
        consistencyRule: "لا توجد كقاعدة مستقلة عامة",

        models: [
            {
                name: "Hyper Growth (1-Step)",
                type: "Challenge",
                profitTarget: "10%",
                maxDailyLoss: "3% Daily Pause",
                maxLoss: "6% Stop Out",
                drawdownType: "Equity-based / ليس Static بسيطًا",
                minDays: "3 أيام رابحة",
                leverage: "1:30",
                firstPayout: "بعد 14 يومًا من تفعيل Funded Trader",
                profitSplit: "حتى 100%",
                commission: "غير مذكور رسميًا بجدول موحد",
                prices: [
                    { size: "$5,000", price: "$74" },
                    { size: "$10,000", price: "غير ظاهر" },
                    { size: "$20,000", price: "غير ظاهر" }
                ]
            },
            {
                name: "High Stakes (2-Step)",
                type: "Challenge",
                profitTarget: "10% (New) / 8% (Classic) ثم 5%",
                maxDailyLoss: "5%",
                maxLoss: "10%",
                drawdownType: "Balance-based allowance / ليس Trailing كلاسيكيًا",
                minDays: "3 أيام رابحة في كل مرحلة",
                leverage: "1:100",
                firstPayout: "بعد 14 يومًا من تفعيل Funded Trader",
                profitSplit: "80% → 100%",
                commission: "غير مذكور رسميًا بجدول موحد",
                prices: [
                    { size: "$2,500", price: "$19" },
                    { size: "$5,000", price: "غير ظاهر" },
                    { size: "$10,000", price: "غير ظاهر" },
                    { size: "$25,000", price: "غير ظاهر" },
                    { size: "$50,000", price: "غير ظاهر" },
                    { size: "$100,000", price: "غير ظاهر" }
                ]
            },
            {
                name: "Bootcamp (3-Step)",
                type: "Challenge",
                profitTarget: "6% ثم 6% ثم 6%",
                maxDailyLoss: "لا يوجد في المراحل / 3% Daily Pause بعد التمويل",
                maxLoss: "5% في المراحل / 4% بعد التمويل",
                drawdownType: "Equity-based / هيكل تدريجي",
                minDays: "غير مذكور كقاعدة أيام موحدة",
                leverage: "1:30",
                firstPayout: "بعد 14 يومًا من تفعيل Funded Trader",
                profitSplit: "حتى 100%",
                commission: "غير مذكور رسميًا بجدول موحد",
                prices: [
                    { size: "$20,000 Plan", price: "$22 entry fee + $50 funded fee" },
                    { size: "$100,000 Plan", price: "غير ظاهر" },
                    { size: "$250,000 Plan", price: "غير ظاهر" }
                ]
            }
        ],

        rules: {
            newsTradingEvaluation: "مسموح (Hyper Growth & Bootcamp مع حظر bracket strategies)، مقيد (High Stakes: حظر أوامر جديدة خلال دقيقتين قبل/بعد الأخبار)",
            newsTradingFunded: "مقيد بشكل مختلف حسب البرنامج",
            overnightHolding: "مسموح",
            weekendHolding: "مسموح (مع ملاحظة swaps مرتفعة للمؤشرات)",
            bestDayRule: "غير موجود",
            timeLimit: "غير محدود",
            eaTrading: "مسموح بشروط (لا Arbitrage/HFT)",
            hedging: "Hedge arbitrage محظور",
            copyTrading: "يحظر نسخ إشارات الغير"
        },

        payout: {
            firstPayout: "بعد 14 يومًا من تفعيل الحساب الممول",
            frequency: "كل أسبوعين بعد آخر سحب معتمد",
            refund: "غير مذكور بوضوح",
            minWithdrawal: "$150 بعد تطبيق profit split",
            fees: "3.5% على Rise والكريبتو والتحويل البنكي"
        },

        pros: [
            "تنوع واضح بين 1-Step و2-Step و3-Step",
            "لا يوجد Time Limit",
            "High Stakes يقدم رافعة 1:100",
            "Hyper Growth وBootcamp يسمحان بالأخبار",
            "السحب موثق جيدًا (أول سحب بعد 14 يومًا)",
            "خطة نمو قوية جدًا (Hyper Growth حتى 4,000,000 دولار)"
        ],

        cons: [
            "Spread/Slippage/Commission غير منشورة بوضوح",
            "Hyper Growth ليس سهلًا (Daily Pause 3% + Stop Out 6%)",
            "Bootcamp أطول وأكثر تدرجًا",
            "قواعد الأخبار تختلف بين البرامج",
            "تفاصيل المنصات أقل وضوحًا من بعض المنافسين",
            "جميع الحسابات Simulated"
        ],

        verdict: "للمبتدئ الجاد: High Stakes هو الخيار الأكثر توازنًا. للسرعة والنمو: Hyper Growth. لميزانية الدخول المنخفضة: Bootcamp. لكن البرامج الثلاثة ليست متشابهة تشغيليًا.",

        faq: [
            { q: "هل الحساب النهائي Live أم Simulated؟", a: "Simulated ضمن بنية prop firm، مع توضيح أن الشركة تعمل عبر pool accounts ومزودي سيولة." },
            { q: "هل تداول الأخبار مسموح؟", a: "في Hyper Growth وBootcamp نعم باستثناء bracket strategies. في High Stakes توجد قيود على تنفيذ أوامر جديدة خلال دقيقتين قبل/بعد الأخبار." },
            { q: "هل يمكن الاحتفاظ بالصفقات لليوم التالي؟", a: "نعم، مسموح في البرامج الثلاثة." }
        ]
    }
};

// Comparison data structure
const comparisonCriteria = [
    { key: "rating", label: "التقييم العام", type: "rating" },
    { key: "category", label: "السوق", type: "text" },
    { key: "platforms", label: "المنصات", type: "list" },
    { key: "timeLimit", label: "Time Limit", type: "text" },
    { key: "consistencyRule", label: "Consistency Rule", type: "text" },
    { key: "models", label: "عدد النماذج", type: "count" },
    { key: "lowestPrice", label: "أقل سعر دخول", type: "text" },
    { key: "highestLeverage", label: "أعلى رافعة", type: "text" },
    { key: "highestProfitSplit", label: "أعلى Profit Split", type: "text" },
    { key: "fastestPayout", label: "أسرع سحب", type: "text" },
    { key: "eaTrading", label: "EA Trading", type: "text" },
    { key: "newsTrading", label: "تداول الأخبار (التقييم)", type: "text" }
];
